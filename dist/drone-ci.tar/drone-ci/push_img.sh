#/bin/bash

docker build --no-cache -t drone-plugin/ansible:latest .
docker tag drone-plugin/ansible:latest reg.weipaitang.com/drone-plugin/ansible:latest
docker push reg.weipaitang.com/drone-plugin/ansible:latest
